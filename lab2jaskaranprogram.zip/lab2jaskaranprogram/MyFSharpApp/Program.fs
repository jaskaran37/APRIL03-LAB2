﻿// For more information see https://aka.ms/fsharp-console-apps
printfn "student name: jaskaran kaur 
student id:22049580"

// Define Coach record
type Coach = {
    Name: string
    FormerPlayer: bool
}

// Define Stats record
type Stats = {
    Wins: int
    Losses: int
}

// Define Team record
type Team = {
    Name: string
    Coach: Coach
    Stats: Stats
}

// Define coaches
let kevinOllie = { Name = "Kevin Ollie"; FormerPlayer = false }
let steveClifford = { Name = "Steve Clifford"; FormerPlayer = false }
let taylorJenkins = { Name = "Taylor Jenkins"; FormerPlayer = false }
let tomThibodeau = { Name = "Tom Thibodeau"; FormerPlayer = false }
let nickNurse = { Name = "Nick Nurse"; FormerPlayer = false }

// Define stats
let brooklynNetsStats = { Wins = 9; Losses = 14 }
let charlotteHornetsStats = { Wins = 18; Losses = 57 }
let memphisGrizzliesStats = { Wins = 25; Losses = 50 }
let newYorkKnicksStats = { Wins = 44; Losses = 31 }
let philadelphia76ersStats = { Wins = 41; Losses = 35 }

// Define teams
let brooklynNets = { Name = "Brooklyn Nets"; Coach = kevinOllie; Stats = brooklynNetsStats }
let charlotteHornets = { Name = "Charlotte Hornets"; Coach = steveClifford; Stats = charlotteHornetsStats }
let memphisGrizzlies = { Name = "Memphis Grizzlies"; Coach = taylorJenkins; Stats = memphisGrizzliesStats }
let newYorkKnicks = { Name = "New York Knicks"; Coach = tomThibodeau; Stats = newYorkKnicksStats }
let philadelphia76ers = { Name = "Philadelphia 76ers"; Coach = nickNurse; Stats = philadelphia76ersStats }

// Create a list of teams
let teams = [brooklynNets; charlotteHornets; memphisGrizzlies; newYorkKnicks; philadelphia76ers]

// Filter successful teams
let successfulTeams = teams |> List.filter (fun team -> team.Stats.Wins > team.Stats.Losses)

// Calculate success percentage
let calculateSuccessPercentage (team: Team) =
    let totalGames = float (team.Stats.Wins + team.Stats.Losses)
    (float team.Stats.Wins) / totalGames * 100.0

// Calculate success percentage for all teams
let successPercentages = successfulTeams |> List.map calculateSuccessPercentage

// Print success percentages
printfn "Success percentages and Coaches:"
List.iter2 (fun team percentage -> printfn "%s (Coach: %s): %.2f%%" team.Name team.Coach.Name percentage) successfulTeams successPercentages











// Define Cuisine discriminated union
type Cuisine =
    | SeafoodCuisine
    | SouthIndianCuisine

// Define MovieType discriminated union
type MovieType =
    | Regular
    | Anime3D
    | RONCOM
    | RegularWithDrinks
    | Anime3DWithPizza
    | RONCOMWithVIPSeating

// Define Activity discriminated union
type Activity =
    | NetflixAndChill
    | Cycling
    | LongDrive of int * float
    | Movie of MovieType
    | Restaurant of Cuisine

// Function to calculate the budget for an activity
let calculateBudget (activity: Activity) =
    match activity with
    | NetflixAndChill -> 0.0
    | Cycling -> 0.0
    | LongDrive (kilometers, fuelChargePerKilometer) ->
        float kilometers * fuelChargePerKilometer
    | Movie movieType ->
        match movieType with
        | Regular -> 12.0
        | Anime3D -> 17.0
        | RONCOM -> 20.0
        | RegularWithDrinks -> 12.0 + 5.0
        | Anime3DWithPizza -> 17.0 + 5.0
        | RONCOMWithVIPSeating -> 20.0 + 5.0
    | Restaurant cuisine ->
        match cuisine with
        | SeafoodCuisine -> 100.0
        | SouthIndianCuisine -> 80.0

// Example usage
let activity1 = Movie Regular
let activity2 = Restaurant SouthIndianCuisine
let activity3 = LongDrive (100, 0.05)

printfn "Budget for activity 1: %.2f CAD" (calculateBudget activity1)
printfn "Budget for activity 2: %.2f CAD" (calculateBudget activity2)
printfn "Budget for activity 3: %.2f CAD" (calculateBudget activity3)
